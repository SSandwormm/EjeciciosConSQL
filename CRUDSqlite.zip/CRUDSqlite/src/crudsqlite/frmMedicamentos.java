package crudsqlite;

import java.awt.Image;
import java.awt.Toolkit;
import java.sql.ResultSet;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class frmMedicamentos extends javax.swing.JFrame {

    DefaultTableModel modelo;

    public frmMedicamentos() {
        initComponents();
        
          this.setTitle("Medicamento");
        Image img = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Recursos/BD.png/"));
        this.setIconImage(img);
        lblLogo.setIcon(new ImageIcon(img.getScaledInstance(lblLogo.getWidth(), lblLogo.getHeight(), Image.SCALE_SMOOTH)));
        
        //centrar
        this.setLocationRelativeTo(null);
        
        
        
        String[] titulos = {"ID", "Nombre", "Laboratorio","Precio","Stock"};
        modelo = new DefaultTableModel(null, titulos);
        tblProductos.setModel(modelo);
        this.mostrarDatos();
        this.Limpiar();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblProductos = new javax.swing.JTable();
        Medicamentos = new javax.swing.JLabel();
        lblID = new javax.swing.JLabel();
        lblNombre = new javax.swing.JLabel();
        lblLaboratorio = new javax.swing.JLabel();
        lblPrecio = new javax.swing.JLabel();
        lblStock = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        txtLaboratorio = new javax.swing.JTextField();
        txtStock = new javax.swing.JTextField();
        txtPrecio = new javax.swing.JTextField();
        btnAgregar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnBorrar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        Made = new javax.swing.JLabel();
        lblLogo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Fondo.setBackground(new java.awt.Color(204, 204, 204));
        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tblProductos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblProductosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblProductos);

        Fondo.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 340, 790, 290));

        Medicamentos.setFont(new java.awt.Font("Trebuchet MS", 2, 48)); // NOI18N
        Medicamentos.setText("Medicamentos ");
        Fondo.add(Medicamentos, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 330, 40));

        lblID.setText("ID :");
        Fondo.add(lblID, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 80, 30, 30));

        lblNombre.setText("Nombre :");
        Fondo.add(lblNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, 60, 30));

        lblLaboratorio.setText("Laboratorio :");
        Fondo.add(lblLaboratorio, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 70, 30));

        lblPrecio.setText("Precio :");
        Fondo.add(lblPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 270, 40, 30));

        lblStock.setText("Stock :");
        Fondo.add(lblStock, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 220, -1, 30));

        txtId.setEditable(false);
        Fondo.add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 70, 70, 40));
        Fondo.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 120, 130, 40));
        Fondo.add(txtLaboratorio, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 170, 130, 40));
        Fondo.add(txtStock, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 220, 130, 40));
        Fondo.add(txtPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 270, 130, 40));

        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });
        Fondo.add(btnAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 270, 100, 40));

        btnEditar.setText("Editar ");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });
        Fondo.add(btnEditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 270, 100, 40));

        btnBorrar.setText("Borrar");
        btnBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarActionPerformed(evt);
            }
        });
        Fondo.add(btnBorrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 270, 100, 40));

        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
        Fondo.add(btnCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 270, 100, 40));

        Made.setText("Made : SSandwormm");
        Fondo.add(Made, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 640, 150, 30));

        lblLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/BD.png"))); // NOI18N
        Fondo.add(lblLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 10, 240, 250));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Fondo, javax.swing.GroupLayout.DEFAULT_SIZE, 858, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Fondo, javax.swing.GroupLayout.DEFAULT_SIZE, 678, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tblProductosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblProductosMouseClicked
                 if (evt.getClickCount() == 1) {
                    JTable receptor = (JTable) evt.getSource();
        
                    txtId.setText(receptor.getModel().getValueAt(receptor.getSelectedRow(), 0).toString());
                    txtNombre.setText(receptor.getModel().getValueAt(receptor.getSelectedRow(), 1).toString());
                    txtLaboratorio.setText(receptor.getModel().getValueAt(receptor.getSelectedRow(), 2).toString());
                    txtStock.setText(receptor.getModel().getValueAt(receptor.getSelectedRow(), 3).toString());
                    txtPrecio.setText(receptor.getModel().getValueAt(receptor.getSelectedRow(), 4).toString());
        
        
                }
                btnAgregar.setEnabled(false);
                btnEditar.setEnabled(true);
                btnBorrar.setEnabled(true);
    }//GEN-LAST:event_tblProductosMouseClicked

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
                conexion objConexion = new conexion();
                productosBL products = recuperarDatos();
                String strSentenciaInsert = String.format("INSERT INTO Productos(ID,Nombre,Laboratorio,Stock,Precio) "
                        + " VALUES (null,'%s', '%s','%s ',' %s')", products.getNombre(), products.getLaboratorio(),products.getStock(),products.getPrecio());
        
                objConexion.ejecutarSentenciaSQL(strSentenciaInsert);
                this.mostrarDatos();
                this.Limpiar();
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
                conexion objConexion = new conexion();
                productosBL products = recuperarDatos();
                String strSentenciaInsert = String.format("UPDATE Productos SET Nombre='%s',"
                        + "Laboratorio='%s',"+"Stock='%s',"+ "Precio='%s',"+"WHERE ID=%d",products.getID(), products.getNombre(), products.getLaboratorio(), products.getStock(),products.getPrecio() );
        
                objConexion.ejecutarSentenciaSQL(strSentenciaInsert);
                this.mostrarDatos();
                this.Limpiar();
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarActionPerformed
                conexion objConexion = new conexion();
                productosBL products = recuperarDatos();
                String strSentenciaInsert = String.format("DELETE FROM Productos WHERE ID=%d ", products.getID());
        
                objConexion.ejecutarSentenciaSQL(strSentenciaInsert);
                this.mostrarDatos();
                this.Limpiar();
    }//GEN-LAST:event_btnBorrarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
                this.Limpiar();
    }//GEN-LAST:event_btnCancelarActionPerformed

      public void mostrarDatos() {
        conexion objConexion = new conexion();
        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }
        try {
            ResultSet resultado = objConexion.consultarRegistros("SELECT * FROM Productos");
            while (resultado.next()) {
                System.out.println(resultado.getString("ID"));
                System.out.println(resultado.getString("Nombre"));
                System.out.println(resultado.getString("Laboratorio"));
                System.out.println(resultado.getString("Stock"));
                System.out.println(resultado.getString("Precio"));
               
                Object[] oUsuario = {resultado.getString("ID"), resultado.getString("Nombre"), resultado.getString("Laboratorio"), resultado.getInt("Precio"), resultado.getInt("Stock")};
                modelo.addRow(oUsuario);
            }
        } catch (Exception e) {
            System.out.println(e);
        }

    }

     public productosBL recuperarDatos() {
        productosBL products = new productosBL();
        int ID = (txtId.getText().isEmpty()) ? 0 : Integer.parseInt(txtId.getText());

        products.setID(ID);
        products.setNombre(txtNombre.getText());
        products.setLaboratorio(txtLaboratorio.getText());
        products.setPrecio(Integer.parseInt(txtPrecio.getText()));
        products.setStock(Integer.parseInt(txtStock.getText()));
        
        return products;
    }

    public void Limpiar() {

        txtId.setText("");
        txtNombre.setText("");
        txtLaboratorio.setText("");
        txtPrecio.setText("");
        txtStock.setText("");

        btnAgregar.setEnabled(true);
        btnEditar.setEnabled(false);
        btnBorrar.setEnabled(false);

    }

    
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmMedicamentos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmMedicamentos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmMedicamentos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmMedicamentos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmMedicamentos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Fondo;
    private javax.swing.JLabel Made;
    private javax.swing.JLabel Medicamentos;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBorrar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblID;
    private javax.swing.JLabel lblLaboratorio;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblPrecio;
    private javax.swing.JLabel lblStock;
    private javax.swing.JTable tblProductos;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtLaboratorio;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtPrecio;
    private javax.swing.JTextField txtStock;
    // End of variables declaration//GEN-END:variables
}
