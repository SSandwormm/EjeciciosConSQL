package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class conexion {

    Connection conectar= null;
    
    public Connection conexion() {

        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            conectar = DriverManager.getConnection("jdbc:mysql://localhost:3306/login", "root", "admin");

        } catch (ClassNotFoundException e) {
            Logger.getLogger(conexion.class.getName()).log(Level.SEVERE, null, e);
            JOptionPane.showMessageDialog(null, "a ocurrido un ClassNotFoundException" + " " + e.getMessage());

        } catch (SQLException e) {
            Logger.getLogger(conexion.class.getName()).log(Level.SEVERE, null, e);
            JOptionPane.showMessageDialog(null, "a ocurrido un SQLException" + " " + e.getMessage());

        }

        return conectar;
        
    }
   
}
