package conexiondb;

import java.sql.*;

public class Conexion {

//    Connection conexion = null;
////    public static void main(String[] args) {
//    
//        public Connection obtenerConexion(){
//        try {
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            String url = "jdbc:sqlserver://DESKTOP-JM6KNV9:1433;databaseName=dbprueba";
//            Connection con = DriverManager.getConnection(url,"SQLServer","admin");
//
//            System.out.println("sirvio");
//        } catch (ClassNotFoundException e) {
//            e.printStackTrace();
//            System.out.println("mla: " + e.toString());
//        } catch (SQLException ex) {
//            ex.printStackTrace();
//            System.out.println("mla: " + ex.toString());
//        }
//
//        return conexion;
//    }
    
    
    public  Connection obtenerConexion() {
        String url = "jdbc:sqlserver://DESKTOP-JM6KNV9:1433;"
                + "databaseName=escuela;"
                + "user=SQLServer;"
                + "password=admin;";
        try {
            Connection con = DriverManager.getConnection(url);
            System.out.println("sirvio");
            return con;
        } catch (Exception e) {
            System.out.println("errorrrr"+e.toString());
            
            return null;
        }
    }

}
