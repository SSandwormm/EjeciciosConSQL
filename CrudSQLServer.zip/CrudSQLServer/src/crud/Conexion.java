package crud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;
import javax.swing.JOptionPane;

public class Conexion {

    Connection con = null;

    public static Connection getConexion() {
        String url = "jdbc:sqlserver://DESKTOP-JM6KNV9:1433;"
                + "databaseName=escuela;"
                + "user=SQLServer;"
                + "password=admin;";
        try {
            Connection con = DriverManager.getConnection(url);
            return con;
        } catch (SQLException e) {
            System.out.println(e.toString());
            return null;
        }
    }

    public static Connection obtenerConexion() {
        String url = "jdbc:sqlserver://DESKTOP-JM6KNV9:1433;"
                + "databaseName=escuela;"
                + "user=SQLServer;"
                + "password=admin;";
        try {
            Connection con = DriverManager.getConnection(url);
            JOptionPane.showMessageDialog(null, "Conectado");
            return con;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error" + e.toString());
            return null;
        }
    }
    
    
    
//    public ResultSet consultarRegistros(String strSentenciaSQL) {
//        try {
//            PreparedStatement pstm = con.prepareStatement(strSentenciaSQL);
//            ResultSet respuesta = pstm.executeQuery();
//            return respuesta;
//
//        } catch (Exception e) {
//            System.out.println(e);
//            return null;
//
//        }
//    }
//    
//        public int ejecutarSentenciaSQL(String strSentenciaSQL) {
//        try {
//            PreparedStatement pstm = con.prepareStatement(strSentenciaSQL);
//            pstm.execute();
//            return 1;
//
//        } catch (SQLException e) {
//            System.out.println(e);
//            return 0;
//
//        }
//    }
}
