package crud;

import java.sql.*;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import javax.swing.ButtonGroup;
import javax.swing.table.DefaultTableModel;

public class Visual extends javax.swing.JFrame {

    ButtonGroup btnGr;
//    DefaultTableModel modeloTabla;

    public Visual() {
        initComponents();
        this.setTitle("Alumnos");
        this.setLocationRelativeTo(null);
        txtId.setVisible(false);
        btnGr = new ButtonGroup();
        btnGr.add(rbMasculino);
        btnGr.add(rbFemenino);
        btnGr.clearSelection();
        cargarTabla();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblAlumnos = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        matricula = new javax.swing.JLabel();
        txtMatricula = new javax.swing.JTextField();
        Nombre = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        edad = new javax.swing.JLabel();
        txtEdad = new javax.swing.JTextField();
        sexo = new javax.swing.JLabel();
        rbMasculino = new javax.swing.JRadioButton();
        rbFemenino = new javax.swing.JRadioButton();
        email = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnElimiar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        txtId = new javax.swing.JTextField();
        lblId = new javax.swing.JLabel();
        alumnnos = new javax.swing.JLabel();
        btnPrueba = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Fondo.setBackground(new java.awt.Color(255, 255, 255));
        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblAlumnos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Id", "Matricula", "Nombre", "Email", "Sexo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblAlumnos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblAlumnosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblAlumnos);

        Fondo.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 420, 350));

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Titulos", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 2, 12))); // NOI18N
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        matricula.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        matricula.setText("Matricula :");
        jPanel2.add(matricula, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 80, 70, 30));

        txtMatricula.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jPanel2.add(txtMatricula, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 80, 170, 30));

        Nombre.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        Nombre.setText("Nombre :");
        jPanel2.add(Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 120, 70, 30));

        txtNombre.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jPanel2.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 120, 170, 30));

        edad.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        edad.setText("Edad :");
        jPanel2.add(edad, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 160, 70, 30));

        txtEdad.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jPanel2.add(txtEdad, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 160, 170, 30));

        sexo.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        sexo.setText("Sexo :");
        jPanel2.add(sexo, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, 70, 30));

        rbMasculino.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        rbMasculino.setText("Masculino");
        jPanel2.add(rbMasculino, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 200, 90, 30));

        rbFemenino.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        rbFemenino.setText("Femenino");
        jPanel2.add(rbFemenino, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 200, 90, 30));

        email.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        email.setText("Email :");
        jPanel2.add(email, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 240, 60, 30));

        txtEmail.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        jPanel2.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 240, 170, 30));

        btnGuardar.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        btnGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RecursosVisuales/agregar-usuario.png"))); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        jPanel2.add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, -1, 30));

        btnModificar.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        btnModificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RecursosVisuales/editar.png"))); // NOI18N
        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });
        jPanel2.add(btnModificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 300, -1, 30));

        btnElimiar.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        btnElimiar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RecursosVisuales/borrar.png"))); // NOI18N
        btnElimiar.setText("Eliminar");
        btnElimiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnElimiarActionPerformed(evt);
            }
        });
        jPanel2.add(btnElimiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 300, 100, 30));

        btnLimpiar.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        btnLimpiar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RecursosVisuales/cancelar.png"))); // NOI18N
        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });
        jPanel2.add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 300, 100, 30));
        jPanel2.add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 40, 40, 30));

        lblId.setText("ID :");
        jPanel2.add(lblId, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 40, 60, 30));

        Fondo.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 90, 450, 350));

        alumnnos.setFont(new java.awt.Font("Tahoma", 2, 48)); // NOI18N
        alumnnos.setText("Alumnos");
        Fondo.add(alumnnos, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 220, 40));

        btnPrueba.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RecursosVisuales/base-de-datos.png"))); // NOI18N
        btnPrueba.setText("Probar Conexion");
        btnPrueba.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPruebaActionPerformed(evt);
            }
        });
        Fondo.add(btnPrueba, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 450, 160, 40));

        jSeparator1.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));
        Fondo.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 870, 20));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Fondo, javax.swing.GroupLayout.DEFAULT_SIZE, 911, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Fondo, javax.swing.GroupLayout.DEFAULT_SIZE, 508, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed

        String matricula = txtMatricula.getText();
        String nombre = txtNombre.getText();
        int edad = Integer.parseInt(txtEdad.getText());
        String email = txtEmail.getText();
        String sexo;
        if (rbMasculino.isSelected() == true) {
            sexo = "M";
        } else if (rbFemenino.isSelected() == true) {
            sexo = "F";
        } else {
            sexo = "M";
        }
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement("INSERT INTO alumnos(matricula,nombre,edad,sexo,email,activo) "
                    + " VALUES (?,?,?,?,?,?)");
            ps.setString(1, matricula);
            ps.setString(2, nombre);
            ps.setInt(3, edad);
            ps.setString(4, sexo);
            ps.setString(5, email);
            ps.setInt(6, 1);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "registro guardado");
            Limpiar();
            cargarTabla();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString());

        }

    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnPruebaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPruebaActionPerformed
        Conexion prueba = new Conexion();
        prueba.obtenerConexion();

    }//GEN-LAST:event_btnPruebaActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        Limpiar();;
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void tblAlumnosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblAlumnosMouseClicked
        try {
            int fila = tblAlumnos.getSelectedRow();
            int id = Integer.parseInt(tblAlumnos.getValueAt(fila, 0).toString());
            PreparedStatement ps;
            ResultSet rs;

            Connection con = Conexion.getConexion();
            ps = con.prepareStatement("SELECT id, matricula, nombre,edad, sexo, email FROM alumnos WHERE id=?");
            ps.setInt(1, id);
            rs = ps.executeQuery();

            while (rs.next()){
                txtId.setText(String.valueOf(id));
                txtMatricula.setText(rs.getString("matricula"));
                txtNombre.setText(rs.getString("nombre"));
                txtEdad.setText(rs.getString("edad"));
                txtEmail.setText(rs.getString("email"));
                if (rs.getString ("sexo").equals("M")) {
                    rbMasculino.setSelected(true);
                }else if (rs.getString("sexo").equals("F")) {
                    rbFemenino.setSelected(false);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,e.toString());
        }
    }//GEN-LAST:event_tblAlumnosMouseClicked

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        int id = Integer.parseInt(txtId.getText());
        String matricula = txtMatricula.getText();
        String nombre = txtNombre.getText();
        int edad = Integer.parseInt(txtEdad.getText());
        String email = txtEmail.getText();
        String sexo;
        if (rbMasculino.isSelected() == true) {
            sexo = "M";
        } else if (rbFemenino.isSelected() == true) {
            sexo = "F";
        } else {
            sexo = "M";
        }
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement("UPDATE alumnos SET matricula=?,"
                    + "nombre=?,edad=?,sexo=?,email=? WHERE id=?");
            ps.setString(1, matricula);
            ps.setString(2, nombre);
            ps.setInt(3, edad);
            ps.setString(4, sexo);
            ps.setString(5, email);
            ps.setInt(6, id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "registro Modificado");
            
            Limpiar();
            cargarTabla();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString());

        }

    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnElimiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnElimiarActionPerformed
        int id = Integer.parseInt(txtId.getText());
       
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement("DELETE FROM alumnos WHERE id=?");
            ps.setInt(1, id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "registro Eliminado");
            
            Limpiar();
            cargarTabla();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString());

        }
    }//GEN-LAST:event_btnElimiarActionPerformed

    public void Limpiar() {
        txtMatricula.setText("");
        txtNombre.setText("");
        txtEdad.setText("");
        txtEmail.setText("");
    }


    private void cargarTabla() {
        DefaultTableModel Tabla = (DefaultTableModel) tblAlumnos.getModel();
        Tabla.setRowCount(0);

        PreparedStatement ps;
        ResultSet rs;
        ResultSetMetaData rsmd;
        int columnas;

        int [] ancho = {10,50,100,30,100};
        for (int i = 0; i < tblAlumnos.getColumnCount(); i++) {
            tblAlumnos.getColumnModel().getColumn(i).setPreferredWidth(ancho[i]);
            
        }
        
        try {
            Connection con = Conexion.getConexion();
            ps = con.prepareStatement("SELECT id, matricula, nombre, sexo, email FROM alumnos");
            rs = ps.executeQuery();
            rsmd = rs.getMetaData();
            columnas = rsmd.getColumnCount();

            while (rs.next()) {
                Object[] fila = new Object[columnas];
                for (int indice = 0; indice < columnas; indice++) {
                    fila[indice] = rs.getObject(indice + 1);
                }
                Tabla.addRow(fila);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Visual.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Visual.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Visual.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Visual.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Visual().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Fondo;
    private javax.swing.JLabel Nombre;
    private javax.swing.JLabel alumnnos;
    private javax.swing.JButton btnElimiar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnPrueba;
    private javax.swing.JLabel edad;
    private javax.swing.JLabel email;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblId;
    private javax.swing.JLabel matricula;
    private javax.swing.JRadioButton rbFemenino;
    private javax.swing.JRadioButton rbMasculino;
    private javax.swing.JLabel sexo;
    private javax.swing.JTable tblAlumnos;
    private javax.swing.JTextField txtEdad;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtMatricula;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}
