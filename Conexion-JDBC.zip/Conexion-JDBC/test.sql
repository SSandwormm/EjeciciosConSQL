use test;

select * from persona;