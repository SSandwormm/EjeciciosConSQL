
package conexiondb;


public class Main {
    public static void main(String[] args) {
        Conexion a = new Conexion();
        a.obtenerConexion();
    }
}
